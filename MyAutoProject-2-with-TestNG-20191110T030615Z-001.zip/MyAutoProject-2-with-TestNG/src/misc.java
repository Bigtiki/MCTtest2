
public class misc {

	
	
	public static void main(String[] args) {
		
		
		System.out.println(System.getProperty("user.dir"));
		
		
	}
	
	
}
